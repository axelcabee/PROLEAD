var searchData=
[
  ['architecture_0',['Architecture',['../namespacemulator.html#a307f16ee456461500b91a4b86e2b8283',1,'mulator']]]
];

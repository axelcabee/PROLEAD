var searchData=
[
  ['memoryrange_0',['MemoryRange',['../struct_software_1_1_settings_struct_1_1_memory_range.html',1,'Software::SettingsStruct']]],
  ['memoryregion_1',['MemoryRegion',['../structmulator_1_1_memory_region.html',1,'mulator']]]
];

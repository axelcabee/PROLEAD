var searchData=
[
  ['shifttype_0',['ShiftType',['../namespacemulator.html#a1a547d928c44738ef9cd0dbb8675f4e6',1,'mulator']]]
];

var searchData=
[
  ['settingsstruct_0',['SettingsStruct',['../struct_hardware_1_1_settings_struct.html',1,'Hardware::SettingsStruct'],['../struct_software_1_1_settings_struct.html',1,'Software::SettingsStruct']]],
  ['shareddatastruct_1',['SharedDataStruct',['../struct_hardware_1_1_shared_data_struct.html',1,'Hardware::SharedDataStruct'],['../struct_software_1_1_shared_data_struct.html',1,'Software::SharedDataStruct']]],
  ['signalstruct_2',['SignalStruct',['../struct_hardware_1_1_signal_struct.html',1,'Hardware']]],
  ['simulationstruct_3',['SimulationStruct',['../struct_hardware_1_1_simulation_struct.html',1,'Hardware::SimulationStruct'],['../struct_software_1_1_simulation_struct.html',1,'Software::SimulationStruct']]]
];

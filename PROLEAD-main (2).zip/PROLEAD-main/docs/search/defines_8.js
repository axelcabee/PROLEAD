var searchData=
[
  ['max_5fname_5flength_0',['Max_Name_Length',['../_hardware_2_definitions_8hpp.html#acf1dedd66aae8103a70f1250179b8f1f',1,'Max_Name_Length():&#160;Definitions.hpp'],['../_software_2_definitions_8hpp.html#acf1dedd66aae8103a70f1250179b8f1f',1,'Max_Name_Length():&#160;Definitions.hpp']]],
  ['max_5fnum_5fregister_1',['Max_Num_Register',['../_software_2_definitions_8hpp.html#a336115ddc9a26282d1ad9bdb289ec668',1,'Definitions.hpp']]]
];

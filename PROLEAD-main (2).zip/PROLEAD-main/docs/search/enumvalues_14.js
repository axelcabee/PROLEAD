var searchData=
[
  ['wfe_0',['WFE',['../namespacemulator.html#aa4991949c68b2149e932f87a885fa05eabee9fd1badd29d33956f1c8302cf4456',1,'mulator']]],
  ['wfi_1',['WFI',['../namespacemulator.html#aa4991949c68b2149e932f87a885fa05ea512e8433c2554ed28f9f3bd377ad1a12',1,'mulator']]]
];

var searchData=
[
  ['register_0',['Register',['../namespacemulator.html#a16b557221e896ca572d70b7713efce4d',1,'mulator']]],
  ['returncode_1',['ReturnCode',['../namespacemulator.html#a1c9141795a0d4349f975ebe08aedc893',1,'mulator']]]
];

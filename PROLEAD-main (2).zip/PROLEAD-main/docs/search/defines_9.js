var searchData=
[
  ['operation_5fand_0',['Operation_AND',['../_hardware_2_definitions_8hpp.html#a48f940116524884f41adaadc36c2dec5',1,'Definitions.hpp']]],
  ['operation_5fnot_1',['Operation_NOT',['../_hardware_2_definitions_8hpp.html#aac317fe6e8ec0e20669e4017e35ca9e7',1,'Definitions.hpp']]],
  ['operation_5for_2',['Operation_OR',['../_hardware_2_definitions_8hpp.html#abdd7f272f72ef7c2136fe6564a7fee00',1,'Definitions.hpp']]],
  ['operation_5fxor_3',['Operation_XOR',['../_hardware_2_definitions_8hpp.html#a9b978e28990f94e78c1ac2c655ca76a3',1,'Definitions.hpp']]]
];

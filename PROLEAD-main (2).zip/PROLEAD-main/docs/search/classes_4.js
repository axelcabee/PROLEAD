var searchData=
[
  ['helperstruct_0',['HelperStruct',['../struct_software_1_1_helper_struct.html',1,'Software']]]
];

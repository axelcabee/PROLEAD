var searchData=
[
  ['operationstruct_0',['OperationStruct',['../struct_hardware_1_1_operation_struct.html',1,'Hardware']]]
];
